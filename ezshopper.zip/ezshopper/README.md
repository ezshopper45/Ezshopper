# Ez Shopper — AI Shopping Assistant

Describe what you want to create and get a personalised shopping list instantly.

## Setup

### Environment Variables
Add the following to your Vercel project settings under Environment Variables:
- `ANTHROPIC_API_KEY` — your Anthropic API key

### Affiliate IDs
Update the `AFFILIATE_IDS` object at the top of `src/App.jsx`:
```js
const AFFILIATE_IDS = {
  amazon:  "your-amazon-tag",
  awin:    "your-awin-id",
  rakuten: "your-rakuten-id",
};
```

## Deploy
1. Push this repo to GitHub
2. Import into Vercel at vercel.com
3. Add your ANTHROPIC_API_KEY environment variable
4. Deploy!
