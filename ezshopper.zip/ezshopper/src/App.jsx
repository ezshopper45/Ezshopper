import { useState, useRef, useEffect, useCallback } from "react";

// ── Affiliate IDs ────────────────────────────────────────────────────────────
// Replace these placeholder values with your real IDs once registered.
// Amazon Associates: sign up at associates.amazon.co.uk
// Currys + Samsung: both available through your Awin account
const AFFILIATE_IDS = {
  amazon:  "ezshopper08-21", // ← Amazon Associates tracking ID
  awin:    "000000",         // ← Replace with your Awin publisher ID
  rakuten: "000000",         // ← Replace with your Rakuten publisher ID
};

const RETAILERS = {
  amazon:  (q) => `https://www.amazon.co.uk/s?tag=${AFFILIATE_IDS.amazon}&k=${encodeURIComponent(q)}`,
  currys:  (q) => `https://www.currys.co.uk/search?q=${encodeURIComponent(q)}&awc=${AFFILIATE_IDS.awin}`,
  samsung: (q) => `https://www.samsung.com/uk/search/?searchvalue=${encodeURIComponent(q)}&awc=${AFFILIATE_IDS.awin}`,
  very:    (q) => `https://www.very.co.uk/e/q/${encodeURIComponent(q)}.end?awc=${AFFILIATE_IDS.awin}`,
  ao:      (q) => `https://ao.com/l/${encodeURIComponent(q)}/?awc=${AFFILIATE_IDS.awin}`,
};

const CATEGORIES = [
  { icon: "◎", label: "Home Cinema", prompt: "I want to build a home cinema setup in my living room" },
  { icon: "⬡", label: "Gaming PC", prompt: "I want to build a high performance gaming PC" },
  { icon: "◈", label: "Smart Home", prompt: "I want to set up a smart home system" },
];

const SYSTEM_PROMPT = `You are Ez Shopper's AI — a sharp, knowledgeable shopping guide that helps people figure out exactly what to buy for any project they want to create.

When a user describes a project or shares an image of a setup:
1. If given an image, analyse it carefully — identify all visible components, devices, and equipment. Then generate a shopping list for what you can see, or for equivalent/similar products if exact models are unclear.
2. Greet them warmly and briefly acknowledge their goal or what you spotted in the image
3. If the project is clear, go straight to recommendations. If not, ask 1-2 targeted clarifying questions first

When recommending, respond with a JSON block inside <products> tags like this:

<products>
[
  {
    "name": "Product Name",
    "description": "What it does and why it is needed for this project",
    "priceRange": "£XX–£XX",
    "midPrice": 99,
    "priority": "essential",
    "searchQuery": "specific search query for this product",
    "preferredRetailer": "amazon"
  }
]
</products>

Rules:
- priority must be "essential", "recommended", or "optional"
- preferredRetailer must be "amazon", "currys", "samsung", "very", or "ao"
- midPrice is a realistic single number estimate in GBP (integer, no symbol)
- ALWAYS use "amazon" as the preferredRetailer unless the product is genuinely not available on Amazon. Amazon should be used for 95% of all products — tech, accessories, cables, smart home, gaming, audio, everything. Only fall back to another retailer as an absolute last resort
- Keep price ranges realistic and UK-based
- Max 8 products. Always include essential items first
- Be warm, direct, and confident — not robotic
- After the products block, add 2-3 sentences of practical advice`;

const themes = {
  dark: {
    bg: "#0a0a0a", surface: "rgba(255,255,255,0.03)", surfaceHover: "rgba(255,255,255,0.07)",
    border: "rgba(255,255,255,0.07)", borderFocus: "rgba(255,255,255,0.22)",
    text: "#f0f0f0", textMuted: "#888", textDim: "#444", inputBg: "rgba(255,255,255,0.05)",
    inputBorder: "rgba(255,255,255,0.09)", headerBg: "rgba(10,10,10,0.9)",
    fadeBg: "linear-gradient(to top, #0a0a0a 65%, transparent)",
    logoBg: "white", logoFill: "#0a0a0a", btnBg: "white", btnText: "#0a0a0a",
    btnDisabled: "rgba(255,255,255,0.07)", userMsgBg: "rgba(255,255,255,0.07)",
    userMsgBorder: "rgba(255,255,255,0.07)", userMsgText: "#ddd",
    divider: "rgba(255,255,255,0.06)", savedBg: "#111", savedHeader: "#161616",
    savedItem: "rgba(255,255,255,0.03)", savedItemBorder: "rgba(255,255,255,0.06)",
    green: "#4ade80", blue: "#60a5fa", headlineFade: "#2e2e2e",
    micActive: "#ef4444", micActiveBg: "rgba(239,68,68,0.15)",
    imagePillBg: "rgba(255,255,255,0.06)", imagePillBorder: "rgba(255,255,255,0.12)",
  },
  light: {
    bg: "#f8f8f6", surface: "rgba(0,0,0,0.03)", surfaceHover: "rgba(0,0,0,0.06)",
    border: "rgba(0,0,0,0.08)", borderFocus: "rgba(0,0,0,0.25)",
    text: "#111", textMuted: "#666", textDim: "#aaa", inputBg: "rgba(0,0,0,0.03)",
    inputBorder: "rgba(0,0,0,0.1)", headerBg: "rgba(248,248,246,0.92)",
    fadeBg: "linear-gradient(to top, #f8f8f6 65%, transparent)",
    logoBg: "#0a0a0a", logoFill: "white", btnBg: "#0a0a0a", btnText: "white",
    btnDisabled: "rgba(0,0,0,0.08)", userMsgBg: "#0a0a0a",
    userMsgBorder: "transparent", userMsgText: "#f0f0f0",
    divider: "rgba(0,0,0,0.07)", savedBg: "#f0f0ee", savedHeader: "#e8e8e6",
    savedItem: "white", savedItemBorder: "rgba(0,0,0,0.07)",
    green: "#16a34a", blue: "#2563eb", headlineFade: "#ccc",
    micActive: "#ef4444", micActiveBg: "rgba(239,68,68,0.12)",
    imagePillBg: "rgba(0,0,0,0.05)", imagePillBorder: "rgba(0,0,0,0.12)",
  },
};

const Logo = ({ t }) => (
  <svg width="32" height="32" viewBox="0 0 100 100" fill="none">
    <rect width="100" height="100" rx="24" fill={t.logoBg}/>
    <rect x="8" y="35" width="84" height="57" rx="11" fill={t.logoFill} opacity="0.95"/>
    <path d="M28 35V27a22 22 0 0 1 44 0v8" stroke={t.logoFill} strokeWidth="5" strokeLinecap="round" fill="none"/>
    <rect x="24" y="50" width="52" height="32" rx="8" fill="#1a2a4a"/>
    <rect x="15" y="59" width="9" height="10" rx="4.5" fill="#2a3a5a"/>
    <rect x="76" y="59" width="9" height="10" rx="4.5" fill="#2a3a5a"/>
    <rect x="29" y="55" width="42" height="16" rx="4" fill="#0d1f3c"/>
    <ellipse cx="40" cy="63" rx="6.5" ry="6" fill="#1a3a5a"/>
    <ellipse cx="40" cy="63" rx="5" ry="4.5" fill="#00bcd4" opacity="0.9"/>
    <ellipse cx="40" cy="63" rx="3" ry="2.8" fill="#00e5ff"/>
    <ellipse cx="38.5" cy="61.5" rx="1.2" ry="1.1" fill="white" opacity="0.65"/>
    <ellipse cx="60" cy="63" rx="6.5" ry="6" fill="#1a3a5a"/>
    <ellipse cx="60" cy="63" rx="5" ry="4.5" fill="#00bcd4" opacity="0.9"/>
    <ellipse cx="60" cy="63" rx="3" ry="2.8" fill="#00e5ff"/>
    <ellipse cx="58.5" cy="61.5" rx="1.2" ry="1.1" fill="white" opacity="0.65"/>
    <path d="M33 76 Q50 83 67 76" stroke="#00bcd4" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
    <line x1="24" y1="59" x2="29" y2="59" stroke="#00bcd4" strokeWidth="1" opacity="0.5"/>
    <line x1="24" y1="64" x2="29" y2="64" stroke="#00bcd4" strokeWidth="1" opacity="0.5"/>
    <line x1="71" y1="59" x2="76" y2="59" stroke="#00bcd4" strokeWidth="1" opacity="0.5"/>
    <line x1="71" y1="64" x2="76" y2="64" stroke="#00bcd4" strokeWidth="1" opacity="0.5"/>
  </svg>
);

const PriorityBadge = ({ priority, t }) => {
  const styles = {
    essential:   { bg: "rgba(22,163,74,0.15)",  color: t.green },
    recommended: { bg: "rgba(96,165,250,0.15)", color: t.blue },
    optional:    { bg: "rgba(115,115,115,0.15)", color: t.textMuted },
  };
  const s = styles[priority] || styles.optional;
  const label = priority ? priority.charAt(0).toUpperCase() + priority.slice(1) : "Optional";
  return (
    <span style={{ background: s.bg, color: s.color, fontSize: "10px", fontWeight: "600", letterSpacing: "0.06em", padding: "3px 8px", borderRadius: "20px", whiteSpace: "nowrap" }}>
      {label.toUpperCase()}
    </span>
  );
};

const ProductCard = ({ product, index, saved, onToggleSave, t }) => {
  const url = (RETAILERS[product.preferredRetailer] || RETAILERS.amazon)(product.searchQuery);
  const isSaved = saved.some(s => s.name === product.name);
  return (
    <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: "14px", padding: "14px 16px", animation: "fadeUp 0.3s ease both", animationDelay: `${index * 55}ms` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "10px", marginBottom: "6px" }}>
        <h3 style={{ margin: 0, fontSize: "14px", fontWeight: "600", color: t.text, lineHeight: 1.4, flex: 1 }}>{product.name}</h3>
        <PriorityBadge priority={product.priority} t={t} />
      </div>
      <p style={{ margin: "0 0 12px", fontSize: "13px", color: t.textMuted, lineHeight: 1.6 }}>{product.description}</p>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
        <span style={{ fontSize: "15px", fontWeight: "700", color: t.text }}>{product.priceRange}</span>
        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          <button onClick={() => onToggleSave(product)} title={isSaved ? "Remove from list" : "Save to list"}
            style={{ width: "34px", height: "34px", borderRadius: "8px", border: `1px solid ${t.border}`, background: isSaved ? t.green : "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s", flexShrink: 0 }}
            onMouseEnter={e => { if (!isSaved) e.currentTarget.style.background = t.surfaceHover; }}
            onMouseLeave={e => { if (!isSaved) e.currentTarget.style.background = "transparent"; }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill={isSaved ? t.logoBg : "none"} stroke={isSaved ? t.logoBg : t.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <a href={url} target="_blank" rel="noopener noreferrer"
            style={{ display: "inline-flex", alignItems: "center", gap: "5px", background: t.btnBg, color: t.btnText, fontSize: "12px", fontWeight: "600", padding: "8px 15px", borderRadius: "8px", textDecoration: "none", transition: "opacity 0.15s", whiteSpace: "nowrap" }}
            onMouseEnter={e => e.currentTarget.style.opacity = "0.8"}
            onMouseLeave={e => e.currentTarget.style.opacity = "1"}>
            Shop Now
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17L17 7M17 7H7M17 7V17"/></svg>
          </a>
        </div>
      </div>
    </div>
  );
};

const TypingDots = ({ t }) => (
  <div style={{ display: "flex", gap: "5px", padding: "4px 0" }}>
    {[0,1,2].map(i => (
      <div key={i} style={{ width: "6px", height: "6px", borderRadius: "50%", background: t.textDim, animation: "blink 1.2s ease infinite", animationDelay: `${i * 0.2}s` }} />
    ))}
  </div>
);

const AssistantMessage = ({ msg, saved, onToggleSave, t }) => {
  const [products, setProducts] = useState([]);
  const [text, setText] = useState("");
  useEffect(() => {
    if (msg.role !== "assistant") return;
    const match = msg.content.match(/<products>([\s\S]*?)<\/products>/);
    if (match) {
      try { setProducts(JSON.parse(match[1])); setText(msg.content.replace(/<products>[\s\S]*?<\/products>/, "").trim()); }
      catch { setText(msg.content); }
    } else { setText(msg.content); }
  }, [msg.content]);

  return (
    <div style={{ marginBottom: "28px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
        <div style={{ width: "26px", height: "26px", borderRadius: "7px", background: t.logoBg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <svg width="14" height="14" viewBox="0 0 100 100" fill="none">
            <rect width="100" height="100" rx="24" fill={t.logoBg}/>
            <rect x="8" y="35" width="84" height="57" rx="11" fill={t.logoFill} opacity="0.95"/>
            <path d="M28 35V27a22 22 0 0 1 44 0v8" stroke={t.logoFill} strokeWidth="5" strokeLinecap="round" fill="none"/>
            <rect x="24" y="50" width="52" height="32" rx="8" fill="#1a2a4a"/>
            <rect x="29" y="55" width="42" height="16" rx="4" fill="#0d1f3c"/>
            <ellipse cx="40" cy="63" rx="5" ry="4.5" fill="#00bcd4" opacity="0.9"/>
            <ellipse cx="40" cy="63" rx="3" ry="2.8" fill="#00e5ff"/>
            <ellipse cx="38.5" cy="61.5" rx="1.2" ry="1.1" fill="white" opacity="0.65"/>
            <ellipse cx="60" cy="63" rx="5" ry="4.5" fill="#00bcd4" opacity="0.9"/>
            <ellipse cx="60" cy="63" rx="3" ry="2.8" fill="#00e5ff"/>
            <ellipse cx="58.5" cy="61.5" rx="1.2" ry="1.1" fill="white" opacity="0.65"/>
            <path d="M33 76 Q50 83 67 76" stroke="#00bcd4" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
          </svg>
        </div>
        <span style={{ fontSize: "11px", fontWeight: "600", color: t.textDim, letterSpacing: "0.08em" }}>EZ SHOPPER</span>
      </div>
      {msg.loading ? <TypingDots t={t} /> : (
        <>
          {text && <div style={{ fontSize: "14px", lineHeight: 1.8, color: t.textMuted, marginBottom: products.length ? "16px" : 0, whiteSpace: "pre-wrap" }}>{text}</div>}
          {products.length > 0 && (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "10px" }}>
                <div style={{ height: "1px", flex: 1, background: t.divider }} />
                <span style={{ fontSize: "10px", color: t.textDim, letterSpacing: "0.08em" }}>{products.length} ITEMS</span>
                <div style={{ height: "1px", flex: 1, background: t.divider }} />
              </div>
              <div style={{ display: "grid", gap: "8px" }}>
                {products.map((p, i) => <ProductCard key={i} product={p} index={i} saved={saved} onToggleSave={onToggleSave} t={t} />)}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

const SavedPanel = ({ saved, onRemove, onClear, t, onClose }) => {
  const total = saved.reduce((sum, p) => sum + (p.midPrice || 0), 0);
  return (
    <div style={{ position: "fixed", top: 0, right: 0, bottom: 0, width: "min(340px, 100vw)", background: t.savedBg, borderLeft: `1px solid ${t.border}`, display: "flex", flexDirection: "column", zIndex: 200, animation: "slideIn 0.25s ease" }}>
      <div style={{ padding: "16px 18px", background: t.savedHeader, borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: "14px", fontWeight: "700", color: t.text }}>My List</div>
          <div style={{ fontSize: "11px", color: t.textMuted, marginTop: "2px" }}>{saved.length} item{saved.length !== 1 ? "s" : ""}</div>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", padding: "4px", color: t.textMuted }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px" }}>
        {saved.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px 20px", color: t.textDim }}>
            <div style={{ fontSize: "28px", marginBottom: "10px" }}>🛒</div>
            <div style={{ fontSize: "13px" }}>No items saved yet.<br/>Tap the bookmark on any product.</div>
          </div>
        ) : saved.map((item, i) => (
          <div key={i} style={{ background: t.savedItem, border: `1px solid ${t.savedItemBorder}`, borderRadius: "10px", padding: "11px 13px", marginBottom: "8px", display: "flex", alignItems: "flex-start", gap: "10px" }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: "13px", fontWeight: "600", color: t.text, lineHeight: 1.35, marginBottom: "3px" }}>{item.name}</div>
              <div style={{ fontSize: "12px", color: t.textMuted }}>{item.priceRange}</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "6px", flexShrink: 0 }}>
              <a href={(RETAILERS[item.preferredRetailer] || RETAILERS.amazon)(item.searchQuery)} target="_blank" rel="noopener noreferrer" style={{ fontSize: "11px", fontWeight: "600", color: t.blue, textDecoration: "none" }}>Shop →</a>
              <button onClick={() => onRemove(item)} style={{ background: "none", border: "none", cursor: "pointer", color: t.textDim, padding: 0, fontSize: "11px", fontFamily: "inherit" }}>Remove</button>
            </div>
          </div>
        ))}
      </div>
      {saved.length > 0 && (
        <div style={{ padding: "14px 18px", borderTop: `1px solid ${t.border}`, background: t.savedHeader }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
            <span style={{ fontSize: "13px", fontWeight: "600", color: t.textMuted }}>Estimated Total</span>
            <span style={{ fontSize: "20px", fontWeight: "700", color: t.text }}>£{total.toLocaleString()}</span>
          </div>
          <div style={{ fontSize: "10px", color: t.textDim, marginBottom: "10px", lineHeight: 1.5 }}>Based on midpoint of each price range. Actual prices may vary.</div>
          <button onClick={onClear} style={{ width: "100%", padding: "9px", borderRadius: "8px", background: "transparent", border: `1px solid ${t.border}`, color: t.textMuted, fontSize: "12px", fontWeight: "600", cursor: "pointer", fontFamily: "inherit" }}>Clear List</button>
        </div>
      )}
    </div>
  );
};

export default function EzShopper() {
  const [isDark, setIsDark] = useState(() => {
    try { return localStorage.getItem("ez-theme") !== "light"; } catch { return true; }
  });
  const t = themes[isDark ? "dark" : "light"];

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [saved, setSaved] = useState(() => {
    try {
      const stored = localStorage.getItem("ez-saved-list");
      return stored ? JSON.parse(stored) : [];
    } catch { return []; }
  });
  const [showSaved, setShowSaved] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(true);
  const [pendingImage, setPendingImage] = useState(null); // { dataUrl, base64, mediaType }

  const bottomRef = useRef(null);
  const textareaRef = useRef(null);
  const recognitionRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (!(window.SpeechRecognition || window.webkitSpeechRecognition)) setVoiceSupported(false);
  }, []);

  // Persist saved list to localStorage whenever it changes
  useEffect(() => {
    try { localStorage.setItem("ez-saved-list", JSON.stringify(saved)); } catch {}
  }, [saved]);

  // Persist theme preference
  useEffect(() => {
    try { localStorage.setItem("ez-theme", isDark ? "dark" : "light"); } catch {}
  }, [isDark]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const autoResize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 120) + "px";
  };

  const toggleSave = useCallback((product) => {
    setSaved(prev => prev.some(p => p.name === product.name) ? prev.filter(p => p.name !== product.name) : [...prev, product]);
  }, []);

  // Handle image file selection
  const handleImageSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target.result;
      const base64 = dataUrl.split(",")[1];
      setPendingImage({ dataUrl, base64, mediaType: file.type });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const sendMessage = async (text, imageOverride) => {
    const userText = (text || input).trim();
    const image = imageOverride || pendingImage;
    if (!userText && !image) return;
    if (loading) return;

    setInput("");
    setPendingImage(null);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    setStarted(true);

    // Build user message content for display
    const displayText = userText || (image ? "Here's an image of a setup I like — can you create a shopping list from this?" : "");

    // Build API message content
    let apiContent;
    if (image) {
      apiContent = [
        { type: "image", source: { type: "base64", media_type: image.mediaType, data: image.base64 } },
        { type: "text", text: userText || "Please analyse this image and create a shopping list of the components or equipment you can see, or equivalent products available to buy in the UK." },
      ];
    } else {
      apiContent = userText;
    }

    const newMessages = [...messages, { role: "user", content: displayText, image: image?.dataUrl }];
    setMessages(newMessages);
    setLoading(true);
    setMessages(prev => [...prev, { role: "assistant", content: "", loading: true }]);

    // Build API messages — convert image messages to proper format
    const apiMessages = newMessages.map(m => ({
      role: m.role,
      content: m.image
        ? [
            { type: "image", source: { type: "base64", media_type: image.mediaType, data: image.base64 } },
            { type: "text", text: m.content },
          ]
        : m.content,
    }));
    // Replace last user message with full apiContent if image
    if (image) {
      apiMessages[apiMessages.length - 1].content = apiContent;
    }

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Something went wrong — please try again.";
      setMessages(prev => [...prev.slice(0, -1), { role: "assistant", content: reply }]);
    } catch {
      setMessages(prev => [...prev.slice(0, -1), { role: "assistant", content: "Something went wrong — please try again." }]);
    }
    setLoading(false);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const toggleVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    if (listening) { recognitionRef.current?.stop(); setListening(false); return; }
    const rec = new SR();
    rec.lang = "en-GB";
    rec.continuous = false;
    rec.interimResults = true;
    rec.onstart = () => setListening(true);
    rec.onresult = (e) => {
      const transcript = Array.from(e.results).map(r => r[0].transcript).join("");
      setInput(transcript);
      setTimeout(() => autoResize(), 0);
      if (e.results[0].isFinal) {
        setTimeout(() => { setListening(false); sendMessage(transcript); }, 400);
      }
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    rec.start();
  };

  const canSend = !loading && (input.trim() || pendingImage);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
        @keyframes blink{0%,80%,100%{opacity:.2;transform:scale(.85);}40%{opacity:1;transform:scale(1);}}
        @keyframes heroIn{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}
        @keyframes pulse{0%,100%{opacity:.5;}50%{opacity:1;}}
        @keyframes slideIn{from{transform:translateX(100%);}to{transform:translateX(0);}}
        @keyframes fadeOverlay{from{opacity:0;}to{opacity:1;}}
        @keyframes micRing{0%{transform:scale(1);opacity:0.7;}100%{transform:scale(1.6);opacity:0;}}
        @keyframes soundBar{0%,100%{transform:scaleY(0.4);}50%{transform:scaleY(1);}}
        @keyframes imageIn{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
        ::-webkit-scrollbar{width:4px;}
        ::-webkit-scrollbar-thumb{background:#ccc;border-radius:2px;}
        textarea{resize:none;font-family:inherit;}
        textarea:focus,input:focus{outline:none;}
        a{text-decoration:none;}
      `}</style>

      <div style={{ minHeight: "100vh", background: t.bg, color: t.text, fontFamily: "'Inter', -apple-system, sans-serif", transition: "background 0.25s, color 0.25s", position: "relative" }}>

        {showSaved && <div onClick={() => setShowSaved(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 199, animation: "fadeOverlay 0.2s ease" }} />}
        {showSaved && <SavedPanel saved={saved} onRemove={toggleSave} onClear={() => { setSaved([]); try { localStorage.removeItem("ez-saved-list"); } catch {} }} t={t} onClose={() => setShowSaved(false)} />}

        {/* Hidden file input */}
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageSelect} style={{ display: "none" }} />

        {/* Header */}
        <header style={{ position: "sticky", top: 0, zIndex: 100, borderBottom: `1px solid ${t.border}`, background: t.headerBg, backdropFilter: "blur(20px)" }}>
          <div style={{ maxWidth: "700px", margin: "0 auto", padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "9px", flexShrink: 0 }}>
              <Logo t={t} />
              <div>
                <div style={{ fontSize: "15px", fontWeight: "700", color: t.text, letterSpacing: "-0.02em" }}>Ez Shopper</div>
                <div style={{ fontSize: "9px", color: t.textDim, letterSpacing: "0.1em", fontWeight: "500", marginTop: "1px" }}>AI SHOPPING ASSISTANT</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <button onClick={() => setIsDark(d => !d)} title="Toggle theme"
                style={{ width: "34px", height: "34px", borderRadius: "9px", background: t.surface, border: `1px solid ${t.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s", color: t.textMuted }}
                onMouseEnter={e => e.currentTarget.style.background = t.surfaceHover}
                onMouseLeave={e => e.currentTarget.style.background = t.surface}>
                {isDark
                  ? <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
                  : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                }
              </button>
              <button onClick={() => setShowSaved(s => !s)}
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "9px", background: t.surface, border: `1px solid ${t.border}`, cursor: "pointer", transition: "all 0.15s", color: t.text, fontFamily: "inherit" }}
                onMouseEnter={e => e.currentTarget.style.background = t.surfaceHover}
                onMouseLeave={e => e.currentTarget.style.background = t.surface}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                <span style={{ fontSize: "12px", fontWeight: "600" }}>List</span>
                {saved.length > 0 && (
                  <span style={{ minWidth: "18px", height: "18px", borderRadius: "9px", background: t.green, color: isDark ? "#0a0a0a" : "white", fontSize: "10px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center", padding: "0 4px" }}>
                    {saved.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>

        {/* Hero */}
        {!started && (
          <div style={{ maxWidth: "700px", margin: "0 auto", padding: "52px 16px 16px", width: "100%", animation: "heroIn 0.5s ease both" }}>
            <h1 style={{ fontSize: "clamp(30px, 6vw, 52px)", fontWeight: "700", color: t.text, lineHeight: 1.1, letterSpacing: "-0.04em", marginBottom: "14px" }}>
              Tell us what<br /><span style={{ color: t.headlineFade }}>you want to create.</span>
            </h1>
            <p style={{ fontSize: "15px", color: t.textMuted, lineHeight: 1.75, maxWidth: "420px", marginBottom: "36px" }}>
              Describe what you want to create — or upload a photo of a setup you love — and we'll build your personalised shopping list.
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px", marginBottom: "36px" }}>
              {CATEGORIES.map(cat => (
                <button key={cat.label} onClick={() => sendMessage(cat.prompt)} disabled={loading}
                  style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: "14px", padding: "18px 16px 15px", textAlign: "left", cursor: "pointer", transition: "all 0.15s", fontFamily: "inherit" }}
                  onMouseEnter={e => e.currentTarget.style.background = t.surfaceHover}
                  onMouseLeave={e => e.currentTarget.style.background = t.surface}>
                  <div style={{ fontSize: "20px", marginBottom: "8px", color: t.textDim }}>{cat.icon}</div>
                  <div style={{ fontSize: "13px", fontWeight: "600", color: t.text, letterSpacing: "-0.01em" }}>{cat.label}</div>
                </button>
              ))}
            </div>
            <AssistantMessage
              msg={{ role: "assistant", content: "Hey! Tell me what you want to create — a home cinema, gaming PC, smart home setup, or anything else. You can also upload a photo of a setup you like and I'll break it down into a shopping list for you.", loading: false }}
              saved={saved} onToggleSave={toggleSave} t={t}
            />
          </div>
        )}

        {/* Chat */}
        <div style={{ maxWidth: "700px", margin: "0 auto", width: "100%", padding: started ? "28px 16px 190px" : "0 16px 190px", flex: 1 }}>
          {started && messages.map((msg, i) =>
            msg.role === "user" ? (
              <div key={i} style={{ display: "flex", justifyContent: "flex-end", marginBottom: "18px" }}>
                <div style={{ maxWidth: "78%", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "8px" }}>
                  {/* Show uploaded image thumbnail in chat */}
                  {msg.image && (
                    <div style={{ borderRadius: "12px", overflow: "hidden", border: `1px solid ${t.border}`, animation: "imageIn 0.3s ease" }}>
                      <img src={msg.image} alt="Uploaded" style={{ display: "block", maxWidth: "220px", maxHeight: "160px", objectFit: "cover" }} />
                    </div>
                  )}
                  {msg.content && (
                    <div style={{ background: t.userMsgBg, border: `1px solid ${t.userMsgBorder}`, color: t.userMsgText, padding: "10px 15px", borderRadius: "18px 18px 4px 18px", fontSize: "14px", lineHeight: 1.65 }}>
                      {msg.content}
                    </div>
                  )}
                </div>
              </div>
            ) : <AssistantMessage key={i} msg={msg} saved={saved} onToggleSave={toggleSave} t={t} />
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input bar */}
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, padding: "10px 16px 20px", background: t.fadeBg }}>
          <div style={{ maxWidth: "700px", margin: "0 auto" }}>

            {/* Image preview pill */}
            {pendingImage && (
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px", animation: "imageIn 0.2s ease" }}>
                <div style={{ position: "relative", display: "inline-flex" }}>
                  <img src={pendingImage.dataUrl} alt="Preview" style={{ width: "44px", height: "44px", borderRadius: "8px", objectFit: "cover", border: `1px solid ${t.border}` }} />
                  <button onClick={() => setPendingImage(null)}
                    style={{ position: "absolute", top: "-6px", right: "-6px", width: "16px", height: "16px", borderRadius: "50%", background: t.textMuted, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                  </button>
                </div>
                <span style={{ fontSize: "12px", color: t.textMuted }}>Image ready — add a note or just send</span>
              </div>
            )}

            {/* Voice indicator */}
            {listening && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginBottom: "8px" }}>
                <div style={{ display: "flex", gap: "3px" }}>
                  {[0,1,2,3].map(i => (
                    <div key={i} style={{ width: "3px", borderRadius: "2px", background: t.micActive, animation: "soundBar 0.8s ease-in-out infinite", animationDelay: `${i * 0.1}s`, height: "16px" }} />
                  ))}
                </div>
                <span style={{ fontSize: "12px", color: t.micActive, fontWeight: "500" }}>Listening...</span>
              </div>
            )}

            <div style={{ display: "flex", alignItems: "flex-end", gap: "8px", background: t.inputBg, border: `1px solid ${t.inputBorder}`, borderRadius: "16px", padding: "9px 9px 9px 15px", transition: "border-color 0.2s" }}
              onFocusCapture={e => e.currentTarget.style.borderColor = t.borderFocus}
              onBlurCapture={e => e.currentTarget.style.borderColor = t.inputBorder}>

              {/* Image upload button */}
              <button onClick={() => fileInputRef.current?.click()} title="Upload an image"
                style={{ width: "34px", height: "34px", borderRadius: "10px", flexShrink: 0, background: "transparent", border: `1px solid ${t.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s", color: t.textMuted }}
                onMouseEnter={e => { e.currentTarget.style.background = t.surfaceHover; e.currentTarget.style.color = t.text; }}
                onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = t.textMuted; }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
              </button>

              <textarea
                ref={textareaRef} rows={1} value={input}
                onChange={e => { setInput(e.target.value); autoResize(); }}
                onKeyDown={handleKey}
                placeholder={listening ? "Listening..." : pendingImage ? "Describe what you want, or just send the image..." : "Describe what you want to create, or upload an image..."}
                disabled={loading}
                style={{ flex: 1, border: "none", background: "transparent", fontSize: "14px", color: t.text, lineHeight: 1.6, paddingTop: "3px", maxHeight: "120px" }}
              />

              <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                {/* Mic button */}
                {voiceSupported && (
                  <button onClick={toggleVoice} title={listening ? "Stop listening" : "Speak your request"}
                    style={{ width: "34px", height: "34px", borderRadius: "10px", flexShrink: 0, background: listening ? t.micActiveBg : "transparent", border: `1px solid ${listening ? t.micActive : t.border}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.2s", position: "relative" }}
                    onMouseEnter={e => { if (!listening) e.currentTarget.style.background = t.surfaceHover; }}
                    onMouseLeave={e => { if (!listening) e.currentTarget.style.background = "transparent"; }}>
                    {listening && <span style={{ position: "absolute", inset: "-4px", borderRadius: "13px", border: `1.5px solid ${t.micActive}`, animation: "micRing 1.2s ease-out infinite", opacity: 0 }} />}
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={listening ? t.micActive : t.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3M8 22h8"/>
                    </svg>
                  </button>
                )}

                {/* Send button */}
                <button onClick={() => sendMessage()} disabled={!canSend}
                  style={{ width: "34px", height: "34px", borderRadius: "10px", flexShrink: 0, background: canSend ? t.btnBg : t.btnDisabled, border: "none", cursor: canSend ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s" }}
                  onMouseEnter={e => { if (canSend) e.currentTarget.style.transform = "scale(1.06)"; }}
                  onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={canSend ? t.btnText : t.textDim} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 2L11 13M22 2L15 22L11 13L2 9L22 2Z"/>
                  </svg>
                </button>
              </div>
            </div>

            <p style={{ fontSize: "10px", color: t.textDim, textAlign: "center", marginTop: "8px" }}>
              Ez Shopper uses affiliate links · we earn a small commission at no extra cost to you
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
